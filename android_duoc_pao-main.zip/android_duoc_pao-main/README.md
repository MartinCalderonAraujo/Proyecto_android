Proyecto Base Android Kotlin DUOC 2025
- Revisar las ramas.
- Abrir el proyecto desde el archivo ProyectoBase no desde la raiz.
- PRUEBA DE COMMIT Y PUSH GITHUB.

